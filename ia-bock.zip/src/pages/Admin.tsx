import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  MessageSquare, 
  Activity, 
  Settings, 
  Trash2, 
  ArrowLeft,
  Save,
  Loader2,
  ShieldCheck
} from 'lucide-react';

export default function Admin() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ users: 0, messages: 0, conversations: 0 });
  const [users, setUsers] = useState([]);
  const [config, setConfig] = useState({ temperature: 0.7, max_tokens: 2048, system_prompt: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user?.role !== 'admin') navigate('/');
    fetchData();
  }, [user]);

  const fetchData = async () => {
    try {
      const [sRes, uRes, cRes] = await Promise.all([
        fetch('/api/admin/stats'),
        fetch('/api/admin/users'),
        fetch('/api/admin/config')
      ]);
      
      const sData = await sRes.json();
      const uData = await uRes.json();
      const cData = await cRes.json();

      setStats(sData && !sData.error ? sData : { users: 0, messages: 0, conversations: 0 });
      setUsers(Array.isArray(uData) ? uData : []);
      setConfig(cData && !cData.error ? cData : { temperature: 0.7, max_tokens: 2048, system_prompt: '' });
    } catch (err) {
      console.error('Failed to fetch admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveConfig = async () => {
    setSaving(true);
    await fetch('/api/admin/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config)
    });
    setSaving(false);
  };

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0a] flex items-center justify-center">
      <Loader2 className="animate-spin text-emerald-500" size={48} />
    </div>
  );

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/')} className="p-2 hover:bg-white/5 rounded-lg transition-colors">
              <ArrowLeft size={24} />
            </button>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <ShieldCheck className="text-emerald-500" />
              Painel Administrativo
            </h1>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-[#171717] p-6 rounded-2xl border border-white/10">
            <div className="flex items-center gap-4 mb-2">
              <Users className="text-emerald-500" />
              <span className="text-gray-400 font-medium">Usuários</span>
            </div>
            <p className="text-4xl font-bold">{stats.users}</p>
          </div>
          <div className="bg-[#171717] p-6 rounded-2xl border border-white/10">
            <div className="flex items-center gap-4 mb-2">
              <MessageSquare className="text-emerald-500" />
              <span className="text-gray-400 font-medium">Mensagens</span>
            </div>
            <p className="text-4xl font-bold">{stats.messages}</p>
          </div>
          <div className="bg-[#171717] p-6 rounded-2xl border border-white/10">
            <div className="flex items-center gap-4 mb-2">
              <Activity className="text-emerald-500" />
              <span className="text-gray-400 font-medium">Conversas</span>
            </div>
            <p className="text-4xl font-bold">{stats.conversations}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* AI Config */}
          <div className="bg-[#171717] p-8 rounded-2xl border border-white/10 space-y-6">
            <h2 className="text-xl font-bold flex items-center gap-3">
              <Settings className="text-emerald-500" />
              Configuração da IA
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">Temperatura ({config.temperature})</label>
                <input 
                  type="range" min="0" max="1" step="0.1" 
                  value={config.temperature}
                  onChange={e => setConfig({...config, temperature: parseFloat(e.target.value)})}
                  className="w-full accent-emerald-500"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Limite de Tokens</label>
                <input 
                  type="number" 
                  value={config.max_tokens}
                  onChange={e => setConfig({...config, max_tokens: parseInt(e.target.value)})}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2"
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">System Prompt</label>
                <textarea 
                  rows={6}
                  value={config.system_prompt}
                  onChange={e => setConfig({...config, system_prompt: e.target.value})}
                  className="w-full bg-[#0a0a0a] border border-white/10 rounded-lg px-4 py-2 resize-none"
                />
              </div>
              <button 
                onClick={handleSaveConfig}
                disabled={saving}
                className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 rounded-xl transition-colors flex items-center justify-center gap-2"
              >
                {saving ? <Loader2 className="animate-spin" /> : <Save size={20} />}
                Salvar Configurações
              </button>
            </div>
          </div>

          {/* User List */}
          <div className="bg-[#171717] p-8 rounded-2xl border border-white/10 flex flex-col">
            <h2 className="text-xl font-bold mb-6 flex items-center gap-3">
              <Users className="text-emerald-500" />
              Gerenciamento de Usuários
            </h2>
            <div className="flex-1 overflow-y-auto space-y-4 max-h-[500px] pr-2">
              {users.map(u => (
                <div key={u.id} className="bg-[#0a0a0a] p-4 rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <p className="font-medium">{u.email}</p>
                    <p className="text-xs text-gray-500 uppercase tracking-widest">{u.role}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:text-red-500 transition-colors">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
