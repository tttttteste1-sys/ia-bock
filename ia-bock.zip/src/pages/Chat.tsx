import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  Plus, 
  MessageSquare, 
  Send, 
  LogOut, 
  Settings, 
  Trash2, 
  Menu, 
  X,
  Code,
  Terminal,
  Cpu,
  Loader2
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { vscDarkPlus } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { motion, AnimatePresence } from 'motion/react';

export default function Chat() {
  const { user, logout } = useAuth();
  const [conversations, setConversations] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    fetchConversations();
  }, []);

  useEffect(() => {
    if (activeId) fetchMessages(activeId);
    else setMessages([]);
  }, [activeId]);

  useEffect(scrollToBottom, [messages]);

  const fetchConversations = async () => {
    try {
      const res = await fetch('/api/conversations');
      const data = await res.json();
      if (Array.isArray(data)) {
        setConversations(data);
        if (data.length > 0 && !activeId) setActiveId(data[0].id);
      } else {
        console.error('Conversations data is not an array:', data);
        setConversations([]);
      }
    } catch (err) {
      console.error('Failed to fetch conversations:', err);
      setConversations([]);
    }
  };

  const fetchMessages = async (id) => {
    try {
      const res = await fetch(`/api/messages?conversationId=${id}`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setMessages(data);
      } else {
        console.error('Messages data is not an array:', data);
        setMessages([]);
      }
    } catch (err) {
      console.error('Failed to fetch messages:', err);
      setMessages([]);
    }
  };

  const createConversation = async () => {
    try {
      const res = await fetch('/api/conversations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: 'Nova Conversa' })
      });
      const data = await res.json();
      if (data && data.id) {
        setConversations(prev => [data, ...prev]);
        setActiveId(data.id);
      }
    } catch (err) {
      console.error('Failed to create conversation:', err);
    }
  };

  const deleteConversation = async (id, e) => {
    e.stopPropagation();
    try {
      const res = await fetch(`/api/conversations/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setConversations(prev => prev.filter(c => c.id !== id));
        if (activeId === id) setActiveId(null);
      }
    } catch (err) {
      console.error('Failed to delete conversation:', err);
    }
  };

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || !activeId || loading) return;

    const userMessage = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMessage, conversationId: activeId })
      });
      const data = await res.json();
      if (data.content) {
        setMessages(prev => [...prev, { role: 'assistant', content: data.content }]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-screen bg-[#0a0a0a] text-white overflow-hidden">
      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {sidebarOpen && (
          <motion.aside
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            className="w-72 bg-[#171717] border-r border-white/10 flex flex-col z-20"
          >
            <div className="p-4">
              <button
                onClick={createConversation}
                className="w-full flex items-center gap-2 px-4 py-3 border border-white/10 rounded-lg hover:bg-white/5 transition-colors text-sm font-medium"
              >
                <Plus size={18} />
                Nova Conversa
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-1">
              {conversations.map(conv => (
                <div
                  key={conv.id}
                  onClick={() => setActiveId(conv.id)}
                  className={`group flex items-center gap-3 px-3 py-3 rounded-lg cursor-pointer transition-colors ${
                    activeId === conv.id ? 'bg-white/10' : 'hover:bg-white/5'
                  }`}
                >
                  <MessageSquare size={16} className="text-gray-400" />
                  <span className="flex-1 text-sm truncate">{conv.title}</span>
                  <button
                    onClick={(e) => deleteConversation(conv.id, e)}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-500 transition-all"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
            </div>

            <div className="p-4 border-t border-white/10 space-y-2">
              {user?.role === 'admin' && (
                <button 
                  onClick={() => window.location.href = '/admin'}
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-400 hover:text-white transition-colors"
                >
                  <Settings size={18} />
                  Painel Admin
                </button>
              )}
              <button
                onClick={logout}
                className="w-full flex items-center gap-3 px-3 py-2 text-sm text-gray-400 hover:text-red-400 transition-colors"
              >
                <LogOut size={18} />
                Sair
              </button>
              <div className="flex items-center gap-3 px-3 py-2 text-xs text-gray-500">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                {user?.email}
              </div>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 flex flex-col relative">
        {/* Header */}
        <header className="h-14 border-b border-white/10 flex items-center px-4 justify-between bg-[#0a0a0a]/80 backdrop-blur-md sticky top-0 z-10">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-white/5 rounded-lg transition-colors"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
          <div className="flex items-center gap-2">
            <Cpu size={20} className="text-emerald-500" />
            <h2 className="font-bold tracking-tight">IA BOCK <span className="text-[10px] bg-emerald-500/20 text-emerald-500 px-1.5 py-0.5 rounded ml-1">PRO</span></h2>
          </div>
          <div className="w-10" />
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-6 max-w-4xl mx-auto w-full">
          {messages.length === 0 && !loading && (
            <div className="h-full flex flex-col items-center justify-center text-center space-y-6 opacity-50">
              <Terminal size={64} className="text-emerald-500" />
              <div>
                <h3 className="text-xl font-bold">Como posso ajudar hoje?</h3>
                <p className="text-sm">Especialista em programação, arquitetura e lógica.</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 w-full max-w-lg">
                <button onClick={() => setInput('Como criar um servidor Express em TypeScript?')} className="p-3 bg-white/5 border border-white/10 rounded-xl text-xs hover:bg-white/10 transition-colors text-left">
                  "Como criar um servidor Express em TypeScript?"
                </button>
                <button onClick={() => setInput('Explique o conceito de Clean Architecture.')} className="p-3 bg-white/5 border border-white/10 rounded-xl text-xs hover:bg-white/10 transition-colors text-left">
                  "Explique o conceito de Clean Architecture."
                </button>
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex gap-4 ${msg.role === 'assistant' ? 'bg-white/5 p-6 rounded-2xl' : ''}`}
            >
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                msg.role === 'assistant' ? 'bg-emerald-500 text-black' : 'bg-white/10 text-white'
              }`}>
                {msg.role === 'assistant' ? <Cpu size={18} /> : <Code size={18} />}
              </div>
              <div className="flex-1 overflow-hidden prose prose-invert max-w-none">
                <ReactMarkdown
                  components={{
                    code({ className, children, ...props }) {
                      const match = /language-(\w+)/.exec(className || '');
                      const isInline = !className;
                      return !isInline && match ? (
                        <SyntaxHighlighter
                          style={vscDarkPlus as any}
                          language={match[1]}
                          PreTag="div"
                          className="rounded-xl !bg-[#0a0a0a] !border !border-white/10 my-4"
                        >
                          {String(children).replace(/\n$/, '')}
                        </SyntaxHighlighter>
                      ) : (
                        <code className="bg-white/10 px-1.5 py-0.5 rounded text-emerald-400" {...props}>
                          {children}
                        </code>
                      );
                    }
                  }}
                >
                  {msg.content}
                </ReactMarkdown>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-4 bg-white/5 p-6 rounded-2xl animate-pulse">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/50 flex items-center justify-center shrink-0">
                <Loader2 className="animate-spin text-black" size={18} />
              </div>
              <div className="flex-1 space-y-2">
                <div className="h-4 bg-white/10 rounded w-3/4" />
                <div className="h-4 bg-white/10 rounded w-1/2" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 bg-gradient-to-t from-[#0a0a0a] via-[#0a0a0a] to-transparent">
          <form
            onSubmit={handleSend}
            className="max-w-4xl mx-auto relative group"
          >
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend(e);
                }
              }}
              placeholder="Envie uma mensagem..."
              className="w-full bg-[#171717] border border-white/10 rounded-2xl px-4 py-4 pr-14 text-white focus:outline-none focus:border-emerald-500/50 transition-all resize-none shadow-2xl min-h-[60px] max-h-[200px]"
              rows={1}
            />
            <button
              type="submit"
              disabled={!input.trim() || loading || !activeId}
              className="absolute right-3 bottom-3 p-2 bg-emerald-500 text-black rounded-xl hover:bg-emerald-600 transition-colors disabled:opacity-50 disabled:hover:bg-emerald-500"
            >
              <Send size={20} />
            </button>
          </form>
          <p className="text-[10px] text-center text-gray-500 mt-2 uppercase tracking-widest">
            IA BOCK pode cometer erros. Verifique informações importantes.
          </p>
        </div>
      </main>
    </div>
  );
}
