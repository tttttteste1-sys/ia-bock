import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Mock Netlify Functions for local/preview environment
  const handleFunction = async (req, res, functionName) => {
    try {
      const module = await import(`./netlify/functions/${functionName}.js`);
      const event = {
        httpMethod: req.method,
        body: JSON.stringify(req.body),
        headers: req.headers,
        queryStringParameters: req.query,
        path: req.path
      };
      const result = await module.handler(event);
      
      if (result.headers) {
        Object.entries(result.headers).forEach(([key, value]) => {
          res.setHeader(key, value);
        });
      }
      
      res.status(result.statusCode || 200).send(result.body);
    } catch (err) {
      console.error(`Error in function ${functionName}:`, err);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };

  app.all('/api/:name*', (req, res) => {
    const functionName = req.params['name'];
    handleFunction(req, res, functionName);
  });

  app.all('/.netlify/functions/:name*', (req, res) => {
    const functionName = req.params['name'];
    handleFunction(req, res, functionName);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
