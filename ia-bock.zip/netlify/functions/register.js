import { getSupabase, jsonResponse } from './utils/auth.js';
import bcrypt from 'bcryptjs';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  try {
    const { email, password } = JSON.parse(event.body);

    if (!email || !password) {
      return jsonResponse({ error: 'Email e senha obrigatórios' }, 400);
    }

    const supabase = getSupabase();
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const { data, error } = await supabase
      .from('users')
      .insert([
        { email, password: hashedPassword, role: 'user' }
      ])
      .select()
      .single();

    if (error) {
      if (error.code === '23505') {
        return jsonResponse({ error: 'Email já cadastrado' }, 400);
      }
      return jsonResponse({ error: error.message }, 400);
    }

    return jsonResponse({ message: 'Usuário criado com sucesso' }, 201);
  } catch (err) {
    console.error(err);
    return jsonResponse({ error: 'Erro interno no servidor' }, 500);
  }
};
