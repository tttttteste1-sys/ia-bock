import { jsonResponse } from './utils/auth.js';
import cookie from 'cookie';

export const handler = async () => {
  const logoutCookie = cookie.serialize('auth_token', '', {
    httpOnly: true,
    secure: true,
    sameSite: 'none',
    expires: new Date(0),
    path: '/'
  });

  return jsonResponse({ message: 'Logged out' }, 200, {
    'Set-Cookie': logoutCookie
  });
};
