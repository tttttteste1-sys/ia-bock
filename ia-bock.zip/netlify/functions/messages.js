import { getSupabase, jsonResponse, verifyAuth } from './utils/auth.js';

export const handler = async (event) => {
  const user = verifyAuth(event);
  if (!user) return jsonResponse({ error: 'Não autorizado' }, 401);

  const conversationId = event.queryStringParameters?.conversationId;

  if (!conversationId) {
    return jsonResponse({ error: 'ID da conversa obrigatório' }, 400);
  }

  try {
    const supabase = getSupabase();
    const { data, error } = await supabase
      .from('messages')
      .select('*')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true });

    return jsonResponse(data || []);
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
};
