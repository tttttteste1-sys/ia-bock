import { getSupabase, jsonResponse } from './utils/auth.js';
import bcrypt from 'bcryptjs';

export const handler = async (event) => {
  // Only allow POST to prevent accidental seeding
  if (event.httpMethod !== 'POST') {
    return jsonResponse({ error: 'Method not allowed. Use POST to seed.' }, 405);
  }

  try {
    const { email, password, secret } = JSON.parse(event.body || '{}');

    // Simple security check
    if (secret !== process.env.SEED_SECRET) {
      return jsonResponse({ error: 'Unauthorized' }, 401);
    }

    if (!email || !password) {
      return jsonResponse({ error: 'Email and password required' }, 400);
    }

    const supabase = getSupabase();

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create admin user
    const { data, error } = await supabase
      .from('users')
      .insert([
        { email, password: hashedPassword, role: 'admin' }
      ])
      .select()
      .single();

    if (error) {
      return jsonResponse({ error: error.message }, 400);
    }

    // Ensure admin_config exists
    await supabase.from('admin_config').upsert({
      id: 'default',
      system_prompt: 'Você é um assistente útil e amigável.',
      temperature: 0.7,
      max_tokens: 2048
    });

    return jsonResponse({ message: 'Admin seeded successfully', user: { email: data.email, role: data.role } }, 201);
  } catch (err) {
    console.error(err);
    return jsonResponse({ error: err.message }, 500);
  }
};
