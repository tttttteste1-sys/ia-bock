import { jsonResponse, verifyAuth } from './utils/auth.js';

export const handler = async (event) => {
  const user = verifyAuth(event);
  if (!user) return jsonResponse({ authenticated: false }, 200);
  return jsonResponse({ authenticated: true, user });
};
