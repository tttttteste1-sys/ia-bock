import { getSupabase, jsonResponse, verifyAuth } from './utils/auth.js';

export const handler = async (event) => {
  const user = verifyAuth(event);
  if (!user || user.role !== 'admin') {
    return jsonResponse({ error: 'Acesso negado' }, 403);
  }

  const { httpMethod, path } = event;

  try {
    const supabase = getSupabase();
    // Stats
    if (path.endsWith('/stats')) {
      const { count: userCount } = await supabase.from('users').select('*', { count: 'exact', head: true });
      const { count: msgCount } = await supabase.from('messages').select('*', { count: 'exact', head: true });
      const { count: convCount } = await supabase.from('conversations').select('*', { count: 'exact', head: true });
      
      return jsonResponse({
        users: userCount,
        messages: msgCount,
        conversations: convCount
      });
    }

    // Users Management
    if (path.endsWith('/users')) {
      if (httpMethod === 'GET') {
        const { data } = await supabase.from('users').select('id, email, role, created_at').order('created_at', { ascending: false });
        return jsonResponse(data);
      }
    }

    // Config Management
    if (path.endsWith('/config')) {
      if (httpMethod === 'GET') {
        const { data } = await supabase.from('admin_config').select('*').eq('id', 'default').single();
        return jsonResponse(data);
      }
      if (httpMethod === 'POST') {
        const body = JSON.parse(event.body);
        const { data } = await supabase
          .from('admin_config')
          .update(body)
          .eq('id', 'default')
          .select()
          .single();
        return jsonResponse(data);
      }
    }

    return jsonResponse({ error: 'Not found' }, 404);
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
};
