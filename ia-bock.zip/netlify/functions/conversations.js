import { getSupabase, jsonResponse, verifyAuth } from './utils/auth.js';

export const handler = async (event) => {
  const user = verifyAuth(event);
  if (!user) return jsonResponse({ error: 'Não autorizado' }, 401);

  const { httpMethod, path } = event;
  const id = path.split('/').pop();

  try {
    const supabase = getSupabase();
    if (httpMethod === 'GET') {
      // List conversations
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });
      
      return jsonResponse(data || []);
    }

    if (httpMethod === 'POST') {
      // Create conversation
      const { title } = JSON.parse(event.body || '{}');
      const { data, error } = await supabase
        .from('conversations')
        .insert([{ user_id: user.id, title: title || 'Nova Conversa' }])
        .select()
        .single();
      
      return jsonResponse(data, 201);
    }

    if (httpMethod === 'DELETE') {
      // Delete conversation
      await supabase
        .from('conversations')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      
      return jsonResponse({ message: 'Deletado' });
    }

    return jsonResponse({ error: 'Method not allowed' }, 405);
  } catch (err) {
    return jsonResponse({ error: err.message }, 500);
  }
};
