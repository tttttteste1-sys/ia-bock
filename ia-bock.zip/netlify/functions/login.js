import { getSupabase, jsonResponse } from './utils/auth.js';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { JWT_SECRET } from './utils/auth.js';
import cookie from 'cookie';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  try {
    const { email, password } = JSON.parse(event.body);

    if (!email || !password) {
      return jsonResponse({ error: 'Email e senha obrigatórios' }, 400);
    }

    const supabase = getSupabase();
    // Find user
    const { data: user, error } = await supabase
      .from('users')
      .select('*')
      .eq('email', email)
      .single();

    if (error || !user) {
      return jsonResponse({ error: 'Credenciais inválidas' }, 401);
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return jsonResponse({ error: 'Credenciais inválidas' }, 401);
    }

    // Create token
    const token = jwt.sign(
      { id: user.id, email: user.email, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Set cookie
    const authCookie = cookie.serialize('auth_token', token, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      path: '/',
      maxAge: 60 * 60 * 24 * 7 // 7 days
    });

    console.log('Setting auth_token cookie:', authCookie.substring(0, 20) + '...');

    return jsonResponse(
      { user: { id: user.id, email: user.email, role: user.role } },
      200,
      { 'Set-Cookie': authCookie }
    );
  } catch (err) {
    console.error(err);
    return jsonResponse({ error: 'Erro interno no servidor' }, 500);
  }
};
