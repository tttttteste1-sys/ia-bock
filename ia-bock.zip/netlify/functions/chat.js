import { getSupabase, jsonResponse, verifyAuth } from './utils/auth.js';
import axios from 'axios';

export const handler = async (event) => {
  if (event.httpMethod !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405);
  }

  const user = verifyAuth(event);
  if (!user) {
    return jsonResponse({ error: 'Não autorizado' }, 401);
  }

  try {
    const { message, conversationId } = JSON.parse(event.body);

    if (!message || !conversationId) {
      return jsonResponse({ error: 'Mensagem e ID da conversa obrigatórios' }, 400);
    }

    const supabase = getSupabase();
    // 1. Get AI Config
    const { data: config } = await supabase
      .from('admin_config')
      .select('*')
      .eq('id', 'default')
      .single();

    // 2. Get Conversation History (Memory)
    const { data: history } = await supabase
      .from('messages')
      .select('role, content')
      .eq('conversation_id', conversationId)
      .order('created_at', { ascending: true })
      .limit(15); // Last 15 messages for context

    // 3. Save User Message
    await supabase.from('messages').insert([
      { conversation_id: conversationId, role: 'user', content: message }
    ]);

    // 4. Prepare GLM Payload
    const messages = [
      { role: 'system', content: config.system_prompt },
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: 'user', content: message }
    ];

    const apiKey = process.env.GLM_API_KEY;
    
    // GLM API Call (Assuming Zhipu AI GLM-4 or similar)
    // URL: https://open.bigmodel.cn/api/paas/v4/chat/completions
    const response = await axios.post(
      'https://open.bigmodel.cn/api/paas/v4/chat/completions',
      {
        model: 'glm-4',
        messages,
        temperature: config.temperature,
        max_tokens: config.max_tokens,
        stream: false
      },
      {
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json'
        }
      }
    );

    const aiContent = response.data.choices[0].message.content;

    // 5. Save Assistant Message
    await supabase.from('messages').insert([
      { conversation_id: conversationId, role: 'assistant', content: aiContent }
    ]);

    return jsonResponse({ content: aiContent });
  } catch (err) {
    console.error('GLM Error:', err.response?.data || err.message);
    return jsonResponse({ error: 'Erro ao processar IA' }, 500);
  }
};
