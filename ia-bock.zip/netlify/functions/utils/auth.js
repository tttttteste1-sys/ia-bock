import { createClient } from '@supabase/supabase-js';
import jwt from 'jsonwebtoken';
import cookie from 'cookie';

let _supabase = null;

export const getSupabase = () => {
  if (!_supabase) {
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) {
      console.error('SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are required environment variables.');
      throw new Error('Supabase configuration missing');
    }
    _supabase = createClient(url, key);
  }
  return _supabase;
};

// Using SUPABASE_SERVICE_ROLE_KEY as the JWT secret to simplify environment variables
export const JWT_SECRET = process.env.SUPABASE_SERVICE_ROLE_KEY;

export const verifyAuth = (event) => {
  const cookieHeader = event.headers.cookie || event.headers.Cookie || '';
  console.log('Cookie header received:', cookieHeader ? 'Present' : 'Empty');
  
  const cookies = cookie.parse(cookieHeader);
  const token = cookies.auth_token;

  if (!token) {
    console.log('No auth_token cookie found in parsed cookies');
    return null;
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    return decoded;
  } catch (err) {
    console.error('JWT verification failed:', err.message);
    return null;
  }
};

export const jsonResponse = (body, statusCode = 200, headers = {}) => {
  return {
    statusCode,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      ...headers
    },
    body: JSON.stringify(body)
  };
};
